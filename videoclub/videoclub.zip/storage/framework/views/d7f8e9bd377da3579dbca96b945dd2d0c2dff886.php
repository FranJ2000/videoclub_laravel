[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/vagrant/code/videoclub/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>