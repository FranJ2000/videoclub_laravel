

<?php $__env->startSection('content'); ?>
	<?php if(session()->has('notif')): ?>
		<div class="row">
			<div class="alert alert-success">
				<button type="button" class="close pl-2" data-dismiss="alert" aria-hidden="true">&times;</button>
				<strong><?php echo e(__('Notification')); ?>: </strong> <?php echo e(__(session()->get('notif'))); ?>

			</div>
		</div>
	<?php endif; ?>

	<div class="row">
		<div class="col-sm-4">
			<img src="<?php echo e($id->poster); ?>" style="height:280px"/>
		</div>

		<div class="col-sm-8">
			<span class="display-4 text-dark"><?php echo e($id->title); ?></span><br>
			<span><b><?php echo e(__('Year')); ?>: </b><?php echo e($id->year); ?></span><br>
			<span><b><?php echo e(__('Director')); ?>: </b><?php echo e($id->director); ?></span><br>
			<br>
			<p><b><?php echo e(__('Spoiler')); ?>: </b><?php echo e($id->synopsis); ?></p>
			<br>
			<?php if( $id->rented == false ): ?>
				<p><b><?php echo e(__('Status')); ?>: </b><?php echo e(__('Movie available')); ?></p>
				<br>
				<!--<button class="btn btn-success">Alquilar película</button>-->
				<form action="<?php echo e(action('CatalogController@putRent', $id->id)); ?>" method="POST">
					<?php echo e(method_field('PUT')); ?>

					<?php echo e(csrf_field()); ?>

					<button type="submit" class="btn btn-success"><?php echo e(__('Rent movie')); ?></button>
				</form>
			<?php else: ?>
				<p><b><?php echo e(__('Status')); ?>: </b><?php echo e(__('Movie currently rented')); ?></p>
				<br>
				<!--<button class="btn btn-danger">Devolver película</button>-->
				<form action="<?php echo e(action('CatalogController@putReturn', $id->id)); ?>" method="POST">
					<?php echo e(method_field('PUT')); ?>

					<?php echo e(csrf_field()); ?>

					<button type="submit" class="btn btn-danger"><?php echo e(__('Return movie')); ?></button>
				</form>
			<?php endif; ?>
			<a href="<?php echo e(url(app()->getLocale().'/catalog/edit/'.$id->id)); ?>"><button class="btn btn-warning"><?php echo e(__('Edit movie')); ?></button></a>
			<!--<a href="/catalog/edit/<?php echo e($id->id); ?>"><button class="btn btn-warning"><?php echo e(__('Edit movie')); ?></button></a>-->
			<form action="<?php echo e(action('CatalogController@deleteMovie', $id->id)); ?>" method="POST">
				<?php echo e(method_field('DELETE')); ?>

				<?php echo e(csrf_field()); ?>

				<button type="submit" class="btn btn-danger"><?php echo e(__('Remove movie')); ?></button>
			</form>
			<a href=" <?php echo e(url(app()->getLocale().'/catalog')); ?>"><button class="btn btn-withe"><?php echo e(__('Return to the catalog')); ?></button></a>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/videoclub/resources/views/catalog/show.blade.php ENDPATH**/ ?>