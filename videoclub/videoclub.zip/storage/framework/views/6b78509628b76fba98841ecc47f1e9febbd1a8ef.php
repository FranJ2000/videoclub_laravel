

<?php $__env->startSection('content'); ?>
	Pantalla principal de sesión
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/videoclub/resources/views/home.blade.php ENDPATH**/ ?>