<?php echo e($slot); ?>

<?php /**PATH /home/vagrant/code/videoclub/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>