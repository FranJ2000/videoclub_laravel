@extends('layouts.master')

@section('content')
	Pantalla principal de sesión
@stop