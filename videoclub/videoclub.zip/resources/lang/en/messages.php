<?php
	return [
		/* Navbar */
		'catalog' => 'Catalog',
		'newFilm' => 'New Film',
		'language' => 'Language',
		'english' => 'English',
		'spanish' => 'Spanish',
		'logout' => 'Logout'
	];